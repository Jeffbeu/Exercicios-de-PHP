<?php
for($contador = 0; $contador <= 50; $contador++)
{
    echo "O contador agora e: " . $contador . "<br>";
}
?>