<?php
$nome = $_GET["nome"];
$salbruto = $_GET["salbruto"];

//Pegar nome
function peganome($nome){
}

//Pegar INSS
function pegaINSS($salbruto){
    if ($salbruto >= 1800 ){
$desconto = $salbruto * 0.11; //11% de desconto
}
    else if($salbruto < 1800 && $salbruto >= 1100){
    $desconto = $salbruto * 0.09; //9% de desconto
}
    else{
    $desconto = $salbruto * 0.08;  //8% de desconto
}
return $desconto;
}
//Termina aqui
//Calcular vale transporte
function valetrasporte($salbruto){
    if ($salbruto >= 1800){
        $vale_desconto = $salbruto * 0.06; //6% de desconto
    }else if ($salbruto > 1800){
        $vale_desconto = $salbruto * 0.06; //6% de desconto
    }
    return $vale_desconto;
}
//Termina aqui
//Calcular bonus aqui
function bonus($salbruto){
    if($salbruto >= 1800 ){
        $bonus = 1000;
    }else if ($salbruto < 1800 && $salbruto >= 1100){
        $bonus = 500;
    }
    else if ($salbruto < 1100){
        $bonus = 300;
    }
    return $bonus;
    }
// Termina aqui
// Calcular refeição  
/*
function refeicao($salbruto){
    if($salbruto >=2500){
        $descontoRefeicao =  500; // desconto de 500 reias no salário 
    }else if ($salbruto < 2500){
        $descontoRefeicao =  400; // desconto de 400 reais no salário
        }
    return $descontoRefeicao;
    }
*/
// Termina aqui
// Calcular salario liquido
function salarioLiquido($salbruto){
        $salarioliquido = $salbruto-(pegaINSS($salbruto) + valetrasporte($salbruto)) + bonus($salbruto);
    return $salarioliquido; 
}
//Termina aqui
//Verificar Cargo
 
function verificarCargo($salbruto){
    if($salbruto >= 1500){
        $situacao = "gerente";
    }else {
        $situacao = "vendedor";
    }
    return $situacao;
}

echo "Nome: ".$nome."<br>";
echo "Salário: ".$salbruto."<br>";
echo "INSS: ".pegaINSS($salbruto)."<br>";
echo "Vale Transporte: ".valetrasporte($salbruto)."<br>";
echo "Bonus: ".bonus($salbruto)."<br>";
echo "Salario Liquido: ".salarioLiquido($salbruto)."<br>";
echo "Cargo: ".verificarCargo($salbruto)."<br>";


?>