<?php   
$nome = $_POST["nome"];
$data = $_POST["data"];

$calc = 2018 - $data;

function peganome($nome){
    echo "nome: ".$nome."<br>";
}

function verificar($calc){
    if($calc >=65){
        $sitacao = "Melhor Idade";
    }
    else if($calc < 65 && $calc >=25){
        $sitacao = "Idade Madura";
    }
    else if($calc <25 && $calc >=18){
        $sitacao = "Idade do Lobo";
    }
    else if($calc <18){
        $sitacao = "Menor de Idade";
    }
    return $sitacao;
}
echo peganome($nome)."<br>";
echo "situação: ".verificar($calc);
?>